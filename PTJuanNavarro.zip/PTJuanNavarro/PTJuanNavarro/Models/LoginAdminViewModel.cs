﻿namespace PTJuanNavarro.Models
{
    public class LoginAdminViewModel
    {
        public string nombre_usuario { get; set; }
        public string Password { get; set; }
    }
}
