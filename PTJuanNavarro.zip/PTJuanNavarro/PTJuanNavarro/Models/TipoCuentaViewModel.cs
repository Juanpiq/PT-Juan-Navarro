﻿namespace PTJuanNavarro.Models
{
    public class TipoCuentaViewModel
    {
    }
}
