﻿namespace PTJuanNavarro.Models
{
    public class LoginClienteViewModel
    {
        public string nombre_usuario { get; set; }
        public string password { get; set; }
    }
}
